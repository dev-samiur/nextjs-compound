module.exports = {
  plugins: ["autoprefixer"],
};
