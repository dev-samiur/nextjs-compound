---
id: dotenv
title: Environment Variables
sidebar_label: Overview
---

This boilerplate uses dotenv plugin to expose environment variables to the Next.js runtime configuration.

Dotenv is a zero-dependency module that loads environment variables from a .env file into process.env.



