export interface ApodPayload {
    [key: string]: string;
    hd?: boolean;
}
