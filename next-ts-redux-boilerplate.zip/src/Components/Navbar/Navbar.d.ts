declare namespace INavbar {
    export interface IProps {}
}

export { INavbar };
